# LQR control using factor graphs

This code is meant to provide a reference for implementing LQR control using GTSAM.  For a
discussion of the intuition behind the code, please see our corresponding [blog post](gtsam.org/2019/11/01/lqr-control).

Provided in this folder are 4 files:
* `dynamics_lti.py` - A module for formulating and simulating linear, time invariant (LTI) dynamics problems.
* `lqr.py` - A module for formulating and solving LQR problems.
* `example0_ricatti.py` - Example code which solves an LQR problem using the traditional dynamic,
  Discrete Algebraic Ricatti Equation method.  This code is just provided as a reference to compare
  the "standard" solution to the factor graph solution.
* `example1_factorgraph.py` - Example code which solves an LQR problem using GTSAM/factor graphs.